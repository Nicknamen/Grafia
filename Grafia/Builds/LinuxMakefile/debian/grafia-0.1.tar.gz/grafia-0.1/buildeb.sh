debmake \
	--email nico@cavalleri.net \
	--package grafia \
	--upstreamversion 0.1 \
	--revision 1 \
	--targz tar.gz
